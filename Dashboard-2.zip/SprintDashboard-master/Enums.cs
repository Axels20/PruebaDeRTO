﻿namespace IQ.Core.Windows.Animation
{
    public class Enums
    {
        public enum TransformType
        {
            Translate,
            Scale,
            Skew,
            Rotate
        }
    }
}