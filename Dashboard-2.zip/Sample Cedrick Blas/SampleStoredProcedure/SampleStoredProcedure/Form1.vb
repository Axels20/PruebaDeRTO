﻿Imports System.Data.SqlClient

'Cedrick R. Blas, Software Developer
'For outsource program catch me here
'cedrickblas@yahoo.com / 09081805286
'Dream IT Code IT

Public Class Form1

    'change your connection string here
    Dim cn As New SqlConnection("Data Source=ECPAY-PC;Initial Catalog=sample;User ID=sa")


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim t
        For Each t In Me.Controls
            If TypeOf t Is TextBox Then
                If t.Text = "" Then
                    MsgBox("Complete Entry!")
                    Exit Sub
                    Exit For
                End If
            End If
        Next


        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "InsertRecord"
            .CommandType = CommandType.StoredProcedure

            'pass parameter
            .Parameters.AddWithValue("@StudentNumber", TextBox1.Text)
            .Parameters.AddWithValue("@Lastname", TextBox2.Text)
            .Parameters.AddWithValue("@Firstname", TextBox3.Text)
            .Parameters.AddWithValue("@Course", TextBox4.Text)

        End With
        Try
            Dim i As Integer = cmd.ExecuteNonQuery
            MsgBox("Save")

            Me.TextBox1.Text = ""
            Me.TextBox2.Text = ""
            Me.TextBox3.Text = ""
            Me.TextBox4.Text = ""

            Call fillGrid()
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub

    Private Sub fillGrid()

        Dim cmd As New SqlCommand
        With cmd
            .Connection = cn
            .CommandText = "SelectRecord"
            .CommandType = CommandType.StoredProcedure
        End With

        Dim dr As SqlDataReader = cmd.ExecuteReader

        Me.ListView1.Items.Clear()
        Do While dr.Read
            With Me.ListView1
                .Items.Add(dr(0))
                With .Items(.Items.Count - 1).SubItems
                    .Add(dr(1))
                    .Add(dr(2))
                    .Add(dr(3))
                    .Add(dr(4))
                End With
            End With
        Loop
        dr.Close()

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ListView1.Columns.Add("", 0)
        Me.ListView1.Columns.Add("Student number", 100)
        Me.ListView1.Columns.Add("Last name", 100)
        Me.ListView1.Columns.Add("First name", 100)
        Me.ListView1.Columns.Add("Course", 100)
        Try
            cn.Open()
            'MsgBox("Successfully Connected to Server!")

            Call fillGrid()
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try
    End Sub
End Class
