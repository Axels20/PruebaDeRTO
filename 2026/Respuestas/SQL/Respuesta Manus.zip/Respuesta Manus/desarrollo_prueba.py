import sqlite3
import pandas as pd
import math

# Conectar a una base de datos SQLite en memoria
conn = sqlite3.connect('prueba_tecnica.db')
cursor = conn.cursor()

# Cargar los datos desde los archivos CSV
barrios_df = pd.read_csv('/home/ubuntu/upload/exa_barrios_cali(1).csv')
dispositivos_df = pd.read_csv('/home/ubuntu/upload/exa_dispositivos_cali(1).csv')
trx_df = pd.read_csv('/home/ubuntu/upload/exa_trx_clientes(1).csv')

# Guardar los datos en tablas SQL
barrios_df.to_sql('barrios', conn, if_exists='replace', index=False)
dispositivos_df.to_sql('dispositivos', conn, if_exists='replace', index=False)
trx_df.to_sql('transacciones', conn, if_exists='replace', index=False)

print("Datos cargados correctamente en la base de datos.")

# --- Ejercicio A ---
# ¿Cuáles son los barrios en los cuales se realizaron los movimientos de al menos el 51% del dinero total tranzado por cada cliente?
query_a = """
WITH TrxBarrios AS (
    SELECT 
        t.num_cliente,
        d.id_barrio,
        SUM(t.mnt_total_trx) as mnt_barrio
    FROM transacciones t
    JOIN dispositivos d ON t.tipo_dispositivo = d.tipo_dispositivo AND t.codigo_dispositivo = d.codigo_dispositivo
    GROUP BY t.num_cliente, d.id_barrio
),
TotalCliente AS (
    SELECT 
        num_cliente,
        SUM(mnt_total_trx) as mnt_total
    FROM transacciones
    GROUP BY num_cliente
)
SELECT 
    tb.num_cliente,
    b.nombre_barrio
FROM TrxBarrios tb
JOIN TotalCliente tc ON tb.num_cliente = tc.num_cliente
JOIN barrios b ON tb.id_barrio = b.id_barrio
WHERE tb.mnt_barrio >= (tc.mnt_total * 0.51)
"""
sol_a = pd.read_sql_query(query_a, conn)
sol_a.to_csv('sol_ej_a.csv', index=False)
print("Ejercicio A completado.")

# --- Ejercicio B ---
# ¿Cuáles son los dispositivos con transacciones de al menos 100 clientes diferentes?
query_b = """
SELECT 
    tipo_dispositivo,
    codigo_dispositivo,
    COUNT(DISTINCT num_cliente) as num_clientes_unicos
FROM transacciones
GROUP BY tipo_dispositivo, codigo_dispositivo
HAVING COUNT(DISTINCT num_cliente) >= 100
"""
sol_b = pd.read_sql_query(query_b, conn)
sol_b.to_csv('sol_ej_b.csv', index=False)
print("Ejercicio B completado.")

# --- Ejercicio C ---
# ¿Cuáles son los 5 barrios donde la mayor cantidad de clientes únicos realizan transacciones en dispositivos tipo POS?
query_c = """
SELECT 
    b.nombre_barrio,
    COUNT(DISTINCT t.num_cliente) as num_clientes_unicos
FROM transacciones t
JOIN dispositivos d ON t.tipo_dispositivo = d.tipo_dispositivo AND t.codigo_dispositivo = d.codigo_dispositivo
JOIN barrios b ON d.id_barrio = b.id_barrio
WHERE t.tipo_dispositivo = 'POS'
GROUP BY b.nombre_barrio
ORDER BY num_clientes_unicos DESC
LIMIT 5
"""
sol_c = pd.read_sql_query(query_c, conn)
sol_c.to_csv('sol_ej_c.csv', index=False)
print("Ejercicio C completado.")

# --- Ejercicio D ---
# ¿Cuáles son las 10 distancias únicas (en kilómetros) de los dispositivos más alejados entre sí del barrio Sucre?
# Definir función Haversine para SQLite
def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0  # Radio de la Tierra en km
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2)**2
    return 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))

conn.create_function("haversine", 4, haversine)

query_d = """
WITH DispositivosSucre AS (
    SELECT 
        d.codigo_dispositivo,
        d.latitud,
        d.longitud
    FROM dispositivos d
    JOIN barrios b ON d.id_barrio = b.id_barrio
    WHERE b.nombre_barrio = 'Sucre'
)
SELECT DISTINCT
    haversine(d1.latitud, d1.longitud, d2.latitud, d2.longitud) as distancia_km
FROM DispositivosSucre d1
CROSS JOIN DispositivosSucre d2
WHERE d1.codigo_dispositivo < d2.codigo_dispositivo
ORDER BY distancia_km DESC
LIMIT 10
"""
sol_d = pd.read_sql_query(query_d, conn)
sol_d.to_csv('sol_ej_d.csv', index=False)
print("Ejercicio D completado.")

conn.close()
