import csv
import sqlite3
import math


def main():
    conn = sqlite3.connect("cali.db")
    cur = conn.cursor()

    conn.create_function("RADIANS", 1, lambda x: math.radians(x))
    conn.create_function("SIN", 1, lambda x: math.sin(x))
    conn.create_function("COS", 1, lambda x: math.cos(x))
    conn.create_function("ASIN", 1, lambda x: math.asin(x))
    conn.create_function("SQRT", 1, lambda x: math.sqrt(x))
    conn.create_function("POWER", 2, lambda x, y: x ** y)

    # Pregunta A
    query_a = """
WITH trx_por_barrio AS (
    SELECT
        t.num_cliente,
        b.nombre_barrio AS barrio,
        SUM(t.mnt_total_trx) AS monto_barrio
    FROM exa_trx_clientes t
    JOIN exa_dispositivos_cali d
      ON t.codigo_dispositivo = d.codigo_dispositivo
    JOIN exa_barrios_cali b
      ON d.id_barrio = b.id_barrio
    GROUP BY t.num_cliente, b.nombre_barrio
),
totales_cliente AS (
    SELECT
        num_cliente,
        SUM(monto_barrio) AS monto_total
    FROM trx_por_barrio
    GROUP BY num_cliente
),
ordenado AS (
    SELECT
        tpb.num_cliente,
        tpb.barrio,
        tpb.monto_barrio,
        tc.monto_total,
        SUM(tpb.monto_barrio) OVER (
            PARTITION BY tpb.num_cliente
            ORDER BY tpb.monto_barrio DESC, tpb.barrio
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS monto_acum
    FROM trx_por_barrio tpb
    JOIN totales_cliente tc
      ON tpb.num_cliente = tc.num_cliente
),
proporciones AS (
    SELECT
        num_cliente,
        barrio,
        monto_barrio,
        monto_total,
        monto_acum,
        monto_acum / monto_total AS propor_acum,
        (monto_acum - monto_barrio) / monto_total AS propor_prev
    FROM ordenado
)
SELECT
    num_cliente AS cliente_id,
    barrio
FROM proporciones
WHERE propor_acum <= 0.51
   OR propor_prev < 0.51
ORDER BY num_cliente, barrio;
"""
    cur.execute(query_a)
    rows_a = cur.fetchall()
    with open("sol_ej_a.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["cliente_id", "barrio"])
        writer.writerows(rows_a)

    # Pregunta B
    query_b = """
SELECT
    codigo_dispositivo AS dispositivo_id,
    COUNT(DISTINCT num_cliente) AS cantidad_clientes_unicos
FROM exa_trx_clientes
GROUP BY codigo_dispositivo
HAVING COUNT(DISTINCT num_cliente) >= 100
ORDER BY cantidad_clientes_unicos DESC, dispositivo_id;
"""
    cur.execute(query_b)
    rows_b = cur.fetchall()
    with open("sol_ej_b.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["dispositivo_id", "cantidad_clientes_unicos"])
        writer.writerows(rows_b)

    # Pregunta C
    query_c = """
WITH dispositivos_pos AS (
    SELECT
        codigo_dispositivo,
        id_barrio
    FROM exa_dispositivos_cali
    WHERE tipo_dispositivo = 'POS'
),
clientes_por_barrio AS (
    SELECT
        b.nombre_barrio AS barrio,
        COUNT(DISTINCT t.num_cliente) AS clientes_unicos
    FROM exa_trx_clientes t
    JOIN dispositivos_pos d
      ON t.codigo_dispositivo = d.codigo_dispositivo
    JOIN exa_barrios_cali b
      ON d.id_barrio = b.id_barrio
    GROUP BY b.nombre_barrio
)
SELECT
    barrio,
    clientes_unicos
FROM clientes_por_barrio
ORDER BY clientes_unicos DESC, barrio
LIMIT 5;
"""
    cur.execute(query_c)
    rows_c = cur.fetchall()
    with open("sol_ej_c.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["barrio", "clientes_unicos"])
        writer.writerows(rows_c)

    # Pregunta D
    query_d = """
WITH dispositivos_sucre AS (
    SELECT
        d.codigo_dispositivo,
        d.latitud,
        d.longitud
    FROM exa_dispositivos_cali d
    JOIN exa_barrios_cali b
      ON d.id_barrio = b.id_barrio
    WHERE UPPER(b.nombre_barrio) = 'SUCRE'
),
pares AS (
    SELECT
        a.codigo_dispositivo AS disp1,
        b.codigo_dispositivo AS disp2,
        6371.0 * 2 * ASIN(
            SQRT(
                POWER(SIN(RADIANS(b.latitud - a.latitud) / 2), 2) +
                COS(RADIANS(a.latitud)) * COS(RADIANS(b.latitud)) *
                POWER(SIN(RADIANS(b.longitud - a.longitud) / 2), 2)
            )
        ) AS distancia_km
    FROM dispositivos_sucre a
    JOIN dispositivos_sucre b
      ON a.codigo_dispositivo < b.codigo_dispositivo
)
SELECT DISTINCT
    distancia_km
FROM pares
ORDER BY distancia_km DESC
LIMIT 10;
"""
    cur.execute(query_d)
    rows_d = cur.fetchall()
    with open("sol_ej_d.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["distancia_km"])
        writer.writerows(rows_d)

    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
