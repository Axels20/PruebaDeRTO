-- ============================================================
-- PRUEBA TÉCNICA DATA MINING — CALI
-- Motor: SQLite 3 (compatible PostgreSQL con ajuste menor)
-- Autor: Axel — Data Engineer & SQL Expert
-- ============================================================

-- ============================================================
-- PASO 1: CREACIÓN DE TABLAS
-- ============================================================

CREATE TABLE IF NOT EXISTS exa_barrios_cali (
    id_barrio     INTEGER PRIMARY KEY,
    nombre_barrio TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS exa_dispositivos_cali (
    tipo_dispositivo   TEXT    NOT NULL,
    codigo_dispositivo INTEGER NOT NULL,
    latitud            REAL    NOT NULL,
    longitud           REAL    NOT NULL,
    id_barrio          INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS exa_trx_clientes (
    num_cliente        REAL    NOT NULL,
    tipo_doc           INTEGER NOT NULL,
    tipo_dispositivo   TEXT    NOT NULL,
    codigo_dispositivo INTEGER NOT NULL,
    num_trx            INTEGER NOT NULL,
    mnt_total_trx      REAL    NOT NULL
);

-- ============================================================
-- PREGUNTA A
-- Barrios donde se realizaron movimientos de al menos el 51%
-- del dinero total transado por cada cliente.
-- Lógica: acumulación DESC por monto, retener barrios
-- mientras el acumulado anterior < 51% del total del cliente.
-- ============================================================

WITH monto_por_barrio AS (
    SELECT
        t.num_cliente,
        b.nombre_barrio          AS barrio,
        SUM(t.mnt_total_trx)     AS monto_barrio
    FROM exa_trx_clientes t
    JOIN exa_dispositivos_cali d ON t.codigo_dispositivo = d.codigo_dispositivo
    JOIN exa_barrios_cali      b ON d.id_barrio           = b.id_barrio
    GROUP BY t.num_cliente, b.nombre_barrio
),
total_por_cliente AS (
    SELECT num_cliente, SUM(monto_barrio) AS monto_total
    FROM monto_por_barrio
    GROUP BY num_cliente
),
acumulado AS (
    SELECT
        m.num_cliente,
        m.barrio,
        m.monto_barrio,
        tc.monto_total,
        SUM(m.monto_barrio) OVER (
            PARTITION BY m.num_cliente
            ORDER BY m.monto_barrio DESC
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS monto_acum
    FROM monto_por_barrio m
    JOIN total_por_cliente tc ON m.num_cliente = tc.num_cliente
)
SELECT num_cliente AS cliente_id, barrio
FROM acumulado
-- Incluir el barrio que cruza el umbral 51%, excluir los posteriores
-- Condición: el acumulado ANTES de sumar este barrio < 51% del total
WHERE (monto_acum - monto_barrio) < (monto_total * 0.51)
ORDER BY num_cliente, barrio;

-- ============================================================
-- PREGUNTA B
-- Dispositivos con transacciones de al menos 100 clientes distintos.
-- ============================================================

SELECT
    codigo_dispositivo          AS dispositivo_id,
    COUNT(DISTINCT num_cliente) AS cantidad_clientes_unicos
FROM exa_trx_clientes
GROUP BY codigo_dispositivo
HAVING COUNT(DISTINCT num_cliente) >= 100
ORDER BY cantidad_clientes_unicos DESC;

-- ============================================================
-- PREGUNTA C
-- Top 5 barrios con mayor cantidad de clientes únicos
-- que transaccionan en dispositivos tipo POS.
-- ============================================================

SELECT
    b.nombre_barrio               AS barrio,
    COUNT(DISTINCT t.num_cliente) AS clientes_unicos
FROM exa_trx_clientes t
JOIN exa_dispositivos_cali d ON t.codigo_dispositivo = d.codigo_dispositivo
                             AND d.tipo_dispositivo   = 'POS'
JOIN exa_barrios_cali      b ON d.id_barrio           = b.id_barrio
GROUP BY b.nombre_barrio
ORDER BY clientes_unicos DESC
LIMIT 5;

-- ============================================================
-- PREGUNTA D
-- 10 distancias únicas más grandes entre pares de dispositivos
-- del barrio Sucre, usando la fórmula de Haversine.
-- Nota: SQLite no tiene RADIANS() ni ASIN() nativos.
-- En PostgreSQL reemplazar PI()/180 por la función RADIANS().
-- ============================================================

-- Versión PostgreSQL (usar si se migra a PG):
/*
WITH dispositivos_sucre AS (
    SELECT d.codigo_dispositivo, d.latitud, d.longitud
    FROM exa_dispositivos_cali d
    JOIN exa_barrios_cali b ON d.id_barrio = b.id_barrio
    WHERE LOWER(TRIM(b.nombre_barrio)) = 'sucre'
),
pares AS (
    SELECT
        a.codigo_dispositivo AS cod_a,
        b.codigo_dispositivo AS cod_b,
        6371.0 * 2.0 * ASIN(SQRT(
            POWER(SIN(RADIANS(b.latitud  - a.latitud)  / 2), 2) +
            COS(RADIANS(a.latitud)) * COS(RADIANS(b.latitud)) *
            POWER(SIN(RADIANS(b.longitud - a.longitud) / 2), 2)
        )) AS distancia_km
    FROM dispositivos_sucre a
    JOIN dispositivos_sucre b ON a.codigo_dispositivo < b.codigo_dispositivo
)
SELECT DISTINCT ROUND(distancia_km::numeric, 6) AS distancia_km
FROM pares
WHERE distancia_km > 0
ORDER BY distancia_km DESC
LIMIT 10;
*/

-- Versión SQLite (Haversine implementada con constante PI/180):
WITH dispositivos_sucre AS (
    SELECT d.codigo_dispositivo, d.latitud, d.longitud
    FROM exa_dispositivos_cali d
    JOIN exa_barrios_cali b ON d.id_barrio = b.id_barrio
    WHERE LOWER(TRIM(b.nombre_barrio)) = 'sucre'
),
pares AS (
    SELECT
        a.codigo_dispositivo AS cod_a,
        b.codigo_dispositivo AS cod_b,
        6371.0 * 2.0 * ASIN(SQRT(
            (SIN(((b.latitud  - a.latitud)  * 3.14159265358979 / 180.0) / 2.0)) *
            (SIN(((b.latitud  - a.latitud)  * 3.14159265358979 / 180.0) / 2.0)) +
            COS(a.latitud  * 3.14159265358979 / 180.0) *
            COS(b.latitud  * 3.14159265358979 / 180.0) *
            (SIN(((b.longitud - a.longitud) * 3.14159265358979 / 180.0) / 2.0)) *
            (SIN(((b.longitud - a.longitud) * 3.14159265358979 / 180.0) / 2.0))
        )) AS distancia_km
    FROM dispositivos_sucre a
    JOIN dispositivos_sucre b ON a.codigo_dispositivo < b.codigo_dispositivo
)
SELECT DISTINCT ROUND(distancia_km, 6) AS distancia_km
FROM pares
WHERE distancia_km > 0
ORDER BY distancia_km DESC
LIMIT 10;
