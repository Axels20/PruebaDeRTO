import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

def preprocess_pipeline(df, is_train=True):
    # 1. Manejo de valores especiales (-1, -2, -3, -4)
    # En riesgo crediticio, estos suelen indicar "Sin información" o "No aplica"
    # Vamos a crear flags para estos casos y luego imputar un valor neutral o extremo
    special_values = [-1, -2, -3, -4]
    
    # Identificar columnas con valores especiales
    cols_with_special = []
    for col in df.select_dtypes(include=[np.number]).columns:
        if col not in ['default', 'f_analisis', 'num_doc']:
            if df[df[col].isin(special_values)].shape[0] > 0:
                cols_with_special.append(col)
                # Crear flag de "No aplica/Sin info"
                df[f'{col}_NA'] = df[col].isin(special_values).astype(int)
    
    # Reemplazar valores especiales por NaN para imputación posterior
    df.replace(special_values, np.nan, inplace=True)
    
    # 2. Imputación de valores faltantes
    # Para modelos de árboles como XGBoost/LightGBM, los NaN se manejan solos,
    # pero para una regresión logística (scorecard tradicional) necesitamos imputar.
    # Usaremos la mediana para variables numéricas.
    for col in df.select_dtypes(include=[np.number]).columns:
        if col not in ['default', 'f_analisis', 'num_doc']:
            df[col] = df[col].fillna(df[col].median())
            
    # 3. Codificación de variables categóricas
    if 'tipo_cliente' in df.columns:
        le = LabelEncoder()
        df['tipo_cliente_enc'] = le.fit_transform(df['tipo_cliente'])
        
    # 4. Feature Engineering simple
    # Ejemplo: Ratio de utilización (si existen las columnas necesarias)
    # CO01END086RO es utilización promedio, CO01END094RO es cupo máximo
    df['utilization_ratio'] = df['CO01END002RO'] / (df['CO01END094RO'] + 1)
    
    return df

# Cargar bases
train = pd.read_csv('base_train.csv')
valid = pd.read_csv('base_validacion.csv')
test = pd.read_csv('base_prueba.csv')

# Aplicar preprocesamiento
train_proc = preprocess_pipeline(train)
valid_proc = preprocess_pipeline(valid)
test_proc = preprocess_pipeline(test)

# Guardar procesadas
train_proc.to_csv('train_proc.csv', index=False)
valid_proc.to_csv('valid_proc.csv', index=False)
test_proc.to_csv('test_proc.csv', index=False)

print("Preprocesamiento completado.")
print(f"Nuevas columnas: {train_proc.columns.tolist()}")
