import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar datos
train = pd.read_csv('base_train.csv')
valid = pd.read_csv('base_validacion.csv')
test = pd.read_csv('base_prueba.csv')

# Resumen básico
print("Resumen de base_train:")
print(train.info())
print("\nValores nulos por columna en train:")
print(train.isnull().sum())

# Análisis de la variable respuesta (default)
print("\nDistribución de 'default' en train:")
print(train['default'].value_counts(normalize=True))

# Análisis de 'tipo_cliente'
print("\nDistribución de 'tipo_cliente' en train:")
print(train['tipo_cliente'].value_counts())

# Estadísticas descriptivas para variables numéricas
print("\nEstadísticas descriptivas (variables numéricas):")
desc = train.describe().T
print(desc)

# Identificar valores especiales (como -1, -2, -3, -4 que parecen ser códigos de nulos)
special_values = [-1, -2, -3, -4]
for col in train.select_dtypes(include=[np.number]).columns:
    count = train[train[col].isin(special_values)].shape[0]
    if count > 0:
        print(f"Columna {col} tiene {count} valores especiales {special_values}")

# Correlación con la variable objetivo
correlations = train.corr(numeric_only=True)['default'].sort_values(ascending=False)
print("\nCorrelación de variables con 'default':")
print(correlations)
