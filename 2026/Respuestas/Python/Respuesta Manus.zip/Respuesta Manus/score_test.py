import pandas as pd
import numpy as np
import xgboost as xgb
import pickle

# Cargar modelo, umbrales y datos de prueba
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('thresholds.pkl', 'rb') as f:
    thresholds = pickle.load(f)

test = pd.read_csv('test_proc.csv')

# Definir variables
exclude_cols = ['num_doc', 'f_analisis', 'default', 'tipo_cliente']
features = [col for col in test.columns if col not in exclude_cols]

# Predicciones de probabilidad
test_probs = model.predict_proba(test[features])[:, 1]
test['prob_default'] = test_probs

# Asignar grupos de riesgo
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']

# Asegurar que los umbrales sean válidos para pd.cut
thresholds = sorted(list(set(thresholds)))
if thresholds[0] > 0: thresholds.insert(0, 0.0)
if thresholds[-1] < 1.0: thresholds.append(1.0)

# Ajustar etiquetas si hay menos umbrales de los necesarios
if len(thresholds) - 1 < len(labels):
    # Usar etiquetas genéricas o las primeras N
    current_labels = labels[:len(thresholds)-1]
else:
    current_labels = labels

test['grupo_riesgo'] = pd.cut(test['prob_default'], bins=thresholds, labels=current_labels, include_lowest=True)

# Asegurar que todos tengan grupo (rellenar con t8 si es necesario)
test['grupo_riesgo'] = test['grupo_riesgo'].fillna('t8')

# Seleccionar solo num_doc y grupo_riesgo para el entregable final
entregable = test[['num_doc', 'grupo_riesgo']]

# Guardar como CSV con separador pipe como se pide en algunas partes, 
# pero las instrucciones dicen CSV (separador pipe) para la entrada, 
# y para la salida dice "formato csv". Usaremos coma por defecto pero aclaremos.
entregable.to_csv('base_prueba_calificada.csv', index=False)

print("Base de prueba calificada y guardada.")
print(f"Distribución de grupos en prueba:")
print(test['grupo_riesgo'].value_counts().sort_index())
