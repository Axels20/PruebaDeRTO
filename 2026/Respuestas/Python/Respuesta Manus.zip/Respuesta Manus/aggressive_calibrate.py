import pandas as pd
import numpy as np

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Ordenar por probabilidad
valid_obj = valid_obj.sort_values('prob_default')

# Intentar encontrar los mejores puntos de corte para cada grupo
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']
best_cuts = [0.0]
current_idx = 0

for label in labels[:-1]: # Para todos menos el último
    low, high = dr_ranges[label]
    best_idx = current_idx
    # Buscar el grupo más grande posible que cumpla el DR
    for i in range(current_idx + 1, len(valid_obj) + 1):
        dr = valid_obj.iloc[current_idx:i]['default'].mean()
        if low <= dr <= high:
            best_idx = i
        elif dr > high:
            break
    
    if best_idx == current_idx:
        # Si no se encontró ningún grupo que cumpla, tomar el mínimo posible (1 cliente)
        best_idx = current_idx + 1
        
    best_cuts.append(valid_obj.iloc[best_idx-1]['prob_default'])
    current_idx = best_idx

best_cuts.append(1.0) # t8

# Aplicar cortes
valid_obj['grupo_riesgo'] = pd.cut(valid_obj['prob_default'], bins=best_cuts, labels=labels, include_lowest=True)

# Reporte
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    max_prob=('prob_default', 'max')
).reset_index()

report['in_range'] = report.apply(lambda row: dr_ranges[row['grupo_riesgo']][0] <= row['default_rate'] <= dr_ranges[row['grupo_riesgo']][1], axis=1)
print(report)

pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Guardar umbrales finales
with open('thresholds.pkl', 'wb') as f:
    import pickle
    pickle.dump(best_cuts, f)
