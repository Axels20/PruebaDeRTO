import pandas as pd
import numpy as np

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo (DR_target)
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Ordenar por probabilidad
valid_obj = valid_obj.sort_values('prob_default')

# Asignación manual por percentiles para forzar el cumplimiento de los rangos
# Este es un proceso iterativo en la vida real. Aquí buscaremos los cortes que cumplan los DR.

def find_thresholds(df, ranges):
    thresholds = [0.0]
    labels = sorted(ranges.keys())
    
    current_idx = 0
    final_thresholds = [0.0]
    
    for label in labels:
        low, high = ranges[label]
        # Buscar el punto de corte tal que el DR del segmento esté en (low, high]
        best_p = thresholds[-1]
        
        for p in np.linspace(thresholds[-1], 1.0, 1000):
            temp_df = df[(df['prob_default'] > thresholds[-1]) & (df['prob_default'] <= p)]
            if len(temp_df) > 0:
                dr = temp_df['default'].mean()
                if dr <= (low + high) / 2: # Intentar estar en el centro del rango
                    best_p = p
                else:
                    break
        final_thresholds.append(best_p)
    
    final_thresholds[-1] = 1.0 # Asegurar que el último sea 1.0
    return final_thresholds

# Intentar una asignación por cuantiles inicial y ajustar
valid_obj['rank'] = valid_obj['prob_default'].rank(pct=True)

# Ajuste manual de puntos de corte (percentiles de la probabilidad)
# Estos valores se ajustan para que el Default Rate de cada grupo caiga en el rango
cuts = [0, 0.15, 0.25, 0.45, 0.60, 0.80, 0.92, 0.98, 1.0]
valid_obj['grupo_riesgo'] = pd.cut(valid_obj['rank'], bins=cuts, labels=['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8'])

report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    min_prob=('prob_default', 'min'),
    max_prob=('prob_default', 'max')
).reset_index()

def check_range(row):
    group = row['grupo_riesgo']
    rate = row['default_rate']
    low, high = dr_ranges[group]
    return low <= rate <= high

report['in_range'] = report.apply(check_range, axis=1)
print(report)

pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Guardar los puntos de corte de probabilidad para aplicar a la base de prueba
prob_thresholds = [0] + report['max_prob'].tolist()
prob_thresholds[-1] = 1.0
print(f"\nUmbrales de probabilidad finales: {prob_thresholds}")

with open('thresholds.pkl', 'wb') as f:
    import pickle
    pickle.dump(prob_thresholds, f)
