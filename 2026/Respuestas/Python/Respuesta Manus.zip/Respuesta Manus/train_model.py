import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.metrics import roc_auc_score, average_precision_score
import pickle

# Cargar datos procesados
train = pd.read_csv('train_proc.csv')
valid = pd.read_csv('valid_proc.csv')

# Definir variables (excluyendo IDs, target y f_analisis)
exclude_cols = ['num_doc', 'f_analisis', 'default', 'tipo_cliente']
features = [col for col in train.columns if col not in exclude_cols]

X_train = train[features]
y_train = train['default']
X_valid = valid[features]
y_valid = valid['default']

# Configurar parámetros de XGBoost
# Nota: n_estimators es el número máximo de árboles
model = xgb.XGBClassifier(
    objective='binary:logistic',
    eval_metric='auc',
    max_depth=4,
    learning_rate=0.05,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    n_estimators=1000,
    early_stopping_rounds=50
)

# Entrenar modelo
model.fit(
    X_train, y_train,
    eval_set=[(X_valid, y_valid)],
    verbose=100
)

# Evaluar
train_preds = model.predict_proba(X_train)[:, 1]
valid_preds = model.predict_proba(X_valid)[:, 1]

print(f"\nROC AUC Train: {roc_auc_score(y_train, train_preds):.4f}")
print(f"ROC AUC Valid: {roc_auc_score(y_valid, valid_preds):.4f}")

# Importancia de variables
importance = pd.Series(model.feature_importances_, index=features).sort_values(ascending=False)
print("\nTop 10 variables importantes:")
print(importance.head(10))

# Guardar modelo
with open('model.pkl', 'wb') as f:
    pickle.dump(model, f)

# Guardar predicciones de validación para calibración
valid['prob_default'] = valid_preds
valid.to_csv('valid_with_preds.csv', index=False)
