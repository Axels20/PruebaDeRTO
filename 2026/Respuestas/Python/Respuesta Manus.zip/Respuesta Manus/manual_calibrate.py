import pandas as pd
import numpy as np

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Ordenar por probabilidad
valid_obj = valid_obj.sort_values('prob_default')

# Función para encontrar el corte óptimo para un rango dado
def find_best_cut(df, start_idx, target_low, target_high):
    best_end_idx = start_idx
    best_dr = 0
    
    # Probar diferentes tamaños de grupo
    for end_idx in range(start_idx + 10, len(df) + 1):
        subset = df.iloc[start_idx:end_idx]
        dr = subset['default'].mean()
        if target_low <= dr <= target_high:
            best_end_idx = end_idx
            best_dr = dr
        elif dr > target_high:
            break # Si el DR ya se pasó del máximo, no seguimos
            
    return best_end_idx, best_dr

# Encontrar cortes secuencialmente
cuts_idx = [0]
current_idx = 0
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7'] # t8 es el resto

for label in labels:
    low, high = dr_ranges[label]
    end_idx, dr = find_best_cut(valid_obj, current_idx, low, high)
    cuts_idx.append(end_idx)
    current_idx = end_idx

cuts_idx.append(len(valid_obj)) # El resto para t8

# Asignar grupos
valid_obj['grupo_riesgo'] = 't8' # Default
for i in range(len(labels)):
    valid_obj.iloc[cuts_idx[i]:cuts_idx[i+1], valid_obj.columns.get_loc('grupo_riesgo')] = labels[i]

# Reporte
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    max_prob=('prob_default', 'max')
).reset_index()

def check_range(row):
    group = row['grupo_riesgo']
    rate = row['default_rate']
    low, high = dr_ranges[group]
    return low <= rate <= high

report['in_range'] = report.apply(check_range, axis=1)
print(report)

pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Umbrales de probabilidad
prob_thresholds = [0] + report['max_prob'].tolist()
prob_thresholds[-1] = 1.0
print(f"\nUmbrales de probabilidad: {prob_thresholds}")

with open('thresholds.pkl', 'wb') as f:
    import pickle
    pickle.dump(prob_thresholds, f)
