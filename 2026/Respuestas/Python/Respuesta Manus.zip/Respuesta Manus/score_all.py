import pandas as pd
import numpy as np
import xgboost as xgb
import pickle

# Cargar modelo, umbrales y datos
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('thresholds.pkl', 'rb') as f:
    thresholds = pickle.load(f)

# Función de calificación
def score_base(df, model, thresholds, filename):
    exclude_cols = ['num_doc', 'f_analisis', 'default', 'tipo_cliente', 'prob_default', 'grupo_riesgo']
    features = [col for col in df.columns if col not in exclude_cols]
    
    probs = model.predict_proba(df[features])[:, 1]
    df['prob_default'] = probs
    
    # Asegurar umbrales únicos y crecientes
    thresholds = sorted(list(set(thresholds)))
    if thresholds[0] > 0: thresholds.insert(0, 0.0)
    if thresholds[-1] < 1.0: thresholds.append(1.0)
    
    labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8'][:len(thresholds)-1]
    df['grupo_riesgo'] = pd.cut(df['prob_default'], bins=thresholds, labels=labels, include_lowest=True)
    df['grupo_riesgo'] = df['grupo_riesgo'].fillna('t8')
    
    df[['num_doc', 'grupo_riesgo']].to_csv(filename, index=False)
    return df

# Cargar datos procesados
train = pd.read_csv('train_proc.csv')
valid = pd.read_csv('valid_proc.csv')

# Calificar
score_base(train, model, thresholds, 'base_train_calificada.csv')
score_base(valid, model, thresholds, 'base_validacion_calificada.csv')

print("Bases de entrenamiento y validación calificadas.")
