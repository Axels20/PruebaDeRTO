import pandas as pd
import numpy as np
import pickle

# Cargar validación calificada
valid = pd.read_csv('valid_proc.csv')
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('thresholds.pkl', 'rb') as f:
    thresholds = pickle.load(f)

# Calificar validación
exclude_cols = ['num_doc', 'f_analisis', 'default', 'tipo_cliente', 'prob_default', 'grupo_riesgo']
features = [col for col in valid.columns if col not in exclude_cols]
valid['prob_default'] = model.predict_proba(valid[features])[:, 1]

thresholds = sorted(list(set(thresholds)))
if thresholds[0] > 0: thresholds.insert(0, 0.0)
if thresholds[-1] < 1.0: thresholds.append(1.0)
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8'][:len(thresholds)-1]
valid['grupo_riesgo'] = pd.cut(valid['prob_default'], bins=thresholds, labels=labels, include_lowest=True)

# Filtrar por objetivo
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Reporte
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    min_prob=('prob_default', 'min'),
    max_prob=('prob_default', 'max')
).reset_index()

report['in_range'] = report.apply(lambda row: dr_ranges[row['grupo_riesgo']][0] <= row['default_rate'] <= dr_ranges[row['grupo_riesgo']][1] if row['grupo_riesgo'] in dr_ranges else False, axis=1)

print("Reporte de Calibración Final (Validación Objetivo):")
print(report.to_string())

pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Guardar reporte
report.to_csv('reporte_calibracion.csv', index=False)
