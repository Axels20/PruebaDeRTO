import pandas as pd
import numpy as np

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Ordenar por probabilidad
valid_obj = valid_obj.sort_values('prob_default')

# Intentar asignar grupos por percentiles y luego ajustar
# Probaremos percentiles para distribuir la población
p_cuts = [0, 0.05, 0.10, 0.20, 0.35, 0.60, 0.85, 0.95, 1.0]
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']

valid_obj['grupo_riesgo'] = pd.qcut(valid_obj['prob_default'], q=p_cuts, labels=labels)

# Reporte inicial
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    max_prob=('prob_default', 'max')
).reset_index()

def check_range(row):
    group = row['grupo_riesgo']
    rate = row['default_rate']
    low, high = dr_ranges[group]
    return low <= rate <= high

report['in_range'] = report.apply(check_range, axis=1)
print("Reporte Inicial (Percentiles):")
print(report)

# Ajuste manual basado en el reporte inicial para maximizar población en rango
# t1 (0-1%): DR actual 0.0097 (OK)
# t2 (1-1.5%): DR actual 0.019 (Muy alto, reducir tamaño)
# t3 (1.5-3%): DR actual 0.024 (OK)
# t4 (3-4.5%): DR actual 0.032 (OK)
# t5 (4.5-8%): DR actual 0.058 (OK)
# t6 (8-15%): DR actual 0.104 (OK)
# t7 (15-30%): DR actual 0.177 (OK)
# t8 (30-100%): DR actual 0.368 (OK)

# Vamos a ajustar los cortes de probabilidad (usando los max_prob del reporte anterior como guía)
prob_cuts = [0, 0.018, 0.025, 0.035, 0.05, 0.08, 0.14, 0.25, 1.0]
valid_obj['grupo_riesgo'] = pd.cut(valid_obj['prob_default'], bins=prob_cuts, labels=labels, include_lowest=True)

report_final = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    max_prob=('prob_default', 'max')
).reset_index()

report_final['in_range'] = report_final.apply(check_range, axis=1)
print("\nReporte Final (Ajustado):")
print(report_final)

pob_en_rango = report_final[report_final['in_range']]['n_clientes'].sum() / report_final['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Guardar umbrales finales
with open('thresholds.pkl', 'wb') as f:
    import pickle
    pickle.dump(prob_cuts, f)
