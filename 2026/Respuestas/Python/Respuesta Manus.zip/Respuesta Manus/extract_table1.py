import pandas as pd
df = pd.read_excel('/home/ubuntu/upload/Archivos.xlsx', sheet_name='Instrucciones')
# Buscar donde dice "Tabla 1"
print(df.iloc[0:25, :].to_string())
