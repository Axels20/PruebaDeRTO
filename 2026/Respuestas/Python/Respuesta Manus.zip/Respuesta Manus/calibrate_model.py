import pandas as pd
import numpy as np

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')

# Filtrar por tipo_cliente = 'objetivo' para la calibración
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Definir la tabla de rangos (Tabla 1)
# T1: [0, 0.01]
# T2: (0.01, 0.015]
# T3: (0.015, 0.03]
# T4: (0.03, 0.045]
# T5: (0.045, 0.08]
# T6: (0.08, 0.15]
# T7: (0.15, 0.30]
# T8: (0.30, 1.00]

thresholds = [0, 0.01, 0.015, 0.03, 0.045, 0.08, 0.15, 0.30, 1.0]
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']

# Asignar grupo basado en la probabilidad
valid_obj['grupo_riesgo'] = pd.cut(valid_obj['prob_default'], bins=thresholds, labels=labels, include_lowest=True)

# Calcular métricas por grupo
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean')
).reset_index()

# Verificar si la tasa de incumplimiento está en rango
def check_range(row):
    group = row['grupo_riesgo']
    rate = row['default_rate']
    
    ranges = {
        't1': (0.0, 0.01),
        't2': (0.01, 0.015),
        't3': (0.015, 0.03),
        't4': (0.03, 0.045),
        't5': (0.045, 0.08),
        't6': (0.08, 0.15),
        't7': (0.15, 0.30),
        't8': (0.30, 1.0)
    }
    
    low, high = ranges[group]
    return low <= rate <= high

report['in_range'] = report.apply(check_range, axis=1)

print("Reporte de Calibración (Validación Objetivo):")
print(report)

# Calcular porcentaje de población en rango
pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")
