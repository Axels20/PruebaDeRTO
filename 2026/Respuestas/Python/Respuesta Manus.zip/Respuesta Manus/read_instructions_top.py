import pandas as pd
df = pd.read_excel('/home/ubuntu/upload/Archivos.xlsx', sheet_name='Instrucciones')
print(df.head(25).to_string())
