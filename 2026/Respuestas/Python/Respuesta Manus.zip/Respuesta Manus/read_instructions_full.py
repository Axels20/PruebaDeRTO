import pandas as pd
df = pd.read_excel('/home/ubuntu/upload/Archivos.xlsx', sheet_name='Instrucciones')
for i, row in df.iterrows():
    print(f"Fila {i}: {row.iloc[0]}")
