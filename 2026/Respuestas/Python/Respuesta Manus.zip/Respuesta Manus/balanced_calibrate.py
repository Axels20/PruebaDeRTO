import pandas as pd
import numpy as np
import pickle

# Cargar validación con predicciones
valid = pd.read_csv('valid_with_preds.csv')
valid_obj = valid[valid['tipo_cliente'] == 'objetivo'].copy()

# Rangos objetivo
dr_ranges = {
    't1': (0.0, 0.01),
    't2': (0.01, 0.015),
    't3': (0.015, 0.03),
    't4': (0.03, 0.045),
    't5': (0.045, 0.08),
    't6': (0.08, 0.15),
    't7': (0.15, 0.30),
    't8': (0.30, 1.0)
}

# Ordenar por probabilidad
valid_obj = valid_obj.sort_values('prob_default')

# Intentar encontrar los mejores puntos de corte para cada grupo con un tamaño mínimo
labels = ['t1', 't2', 't3', 't4', 't5', 't6', 't7', 't8']
best_cuts = [0.0]
current_idx = 0
min_size = 10 # Reducir tamaño mínimo para más flexibilidad

for label in labels[:-1]:
    low, high = dr_ranges[label]
    best_idx = current_idx + min_size
    
    # Buscar el grupo más grande posible que cumpla el DR
    found = False
    for i in range(current_idx + min_size, len(valid_obj) + 1):
        dr = valid_obj.iloc[current_idx:i]['default'].mean()
        if low <= dr <= high:
            best_idx = i
            found = True
        elif dr > high and found:
            break
            
    if best_idx > len(valid_obj):
        best_idx = len(valid_obj)
        
    prob_at_idx = valid_obj.iloc[best_idx-1]['prob_default']
    # Asegurar que los cortes sean crecientes
    if prob_at_idx <= best_cuts[-1]:
        prob_at_idx = best_cuts[-1] + 0.000001
        
    best_cuts.append(prob_at_idx)
    current_idx = best_idx

# Asegurar que el último corte sea 1.0
if 1.0 <= best_cuts[-1]:
    best_cuts[-1] = 1.000001
else:
    best_cuts.append(1.0)

# El número de cortes debe ser len(labels) + 1
if len(best_cuts) > len(labels) + 1:
    best_cuts = best_cuts[:len(labels)] + [1.0]
elif len(best_cuts) < len(labels) + 1:
    # Rellenar con valores intermedios si faltan
    while len(best_cuts) < len(labels) + 1:
        best_cuts.insert(-1, best_cuts[-2] + 0.000001)

# Aplicar cortes
valid_obj['grupo_riesgo'] = pd.cut(valid_obj['prob_default'], bins=best_cuts, labels=labels, include_lowest=True)

# Reporte
report = valid_obj.groupby('grupo_riesgo', observed=False).agg(
    n_clientes=('num_doc', 'count'),
    defaults=('default', 'sum'),
    default_rate=('default', 'mean'),
    max_prob=('prob_default', 'max')
).reset_index()

report['in_range'] = report.apply(lambda row: dr_ranges[row['grupo_riesgo']][0] <= row['default_rate'] <= dr_ranges[row['grupo_riesgo']][1], axis=1)
print(report)

pob_en_rango = report[report['in_range']]['n_clientes'].sum() / report['n_clientes'].sum()
print(f"\nPorcentaje de población en rango: {pob_en_rango:.2%}")

# Guardar umbrales finales
with open('thresholds.pkl', 'wb') as f:
    pickle.dump(best_cuts, f)
