import pandas as pd
import numpy as np

def clean_sheet_data(sheet_name):
    # Leer la hoja
    df_raw = pd.read_excel('/home/ubuntu/upload/Archivos.xlsx', sheet_name=sheet_name)
    
    # La primera columna contiene los datos separados por '|'
    # Necesitamos extraer el nombre de las columnas de la primera fila de datos
    header_line = df_raw.columns[0]
    data_lines = df_raw.iloc[:, 0].astype(str).tolist()
    
    # Crear una lista de listas con los datos
    data = [line.split('|') for line in data_lines]
    columns = header_line.split('|')
    
    # Crear el DataFrame final
    df = pd.DataFrame(data, columns=columns)
    
    # Convertir columnas numéricas (excepto las categóricas conocidas)
    for col in df.columns:
        if col not in ['tipo_cliente', 'f_analisis', 'num_doc']:
            try:
                df[col] = pd.to_numeric(df[col])
            except:
                pass
    
    return df

# Procesar las bases
print("Procesando base_train...")
base_train = clean_sheet_data('base_train')
print("Procesando base_validacion...")
base_validacion = clean_sheet_data('base_validacion')
print("Procesando base_prueba...")
base_prueba = clean_sheet_data('base_prueba')

# Guardar como CSV para uso futuro
base_train.to_csv('base_train.csv', index=False)
base_validacion.to_csv('base_validacion.csv', index=False)
base_prueba.to_csv('base_prueba.csv', index=False)

print("Bases procesadas y guardadas.")
print(f"Train shape: {base_train.shape}")
print(f"Validacion shape: {base_validacion.shape}")
print(f"Prueba shape: {base_prueba.shape}")
