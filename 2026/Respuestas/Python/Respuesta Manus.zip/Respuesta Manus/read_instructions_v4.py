import pandas as pd
df = pd.read_excel('/home/ubuntu/upload/Archivos.xlsx', sheet_name='Instrucciones')
print(df.iloc[10:15, :].to_string())
