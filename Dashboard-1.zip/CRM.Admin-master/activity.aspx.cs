﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class activity_comments : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void frmActivities_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    {
        TextBox Started = frmActivities.FindControl("txtStarted") as TextBox;
        TextBox Due = frmActivities.FindControl("txtDue") as TextBox;
        TextBox Completed = frmActivities.FindControl("txtCompleted") as TextBox;
        HiddenField StartedTime = frmActivities.FindControl("hdnStartedTime") as HiddenField;
        HiddenField DueTime = frmActivities.FindControl("hdnDueTime") as HiddenField;
        HiddenField CompletedTime = frmActivities.FindControl("hdnCompletedTime") as HiddenField;
        if (Started.Text != "")
        {
            dsActivities.UpdateParameters.Add("creationdate", System.Data.DbType.DateTime, Started.Text + " " + StartedTime.Value);
        }
        else
        {
            dsActivities.UpdateParameters.Add("creationdate", null);
        }
        if (Due.Text != "")
        {
            dsActivities.UpdateParameters.Add("duedate", System.Data.DbType.DateTime, Due.Text + " " + DueTime.Value);
        }
        else
        {
            dsActivities.UpdateParameters.Add("duedate", null);
        }
        if (Completed.Text != "")
        {
            dsActivities.UpdateParameters.Add("completiondate", System.Data.DbType.DateTime, Completed.Text + " " + CompletedTime.Value);
        }
        else
        {
            dsActivities.UpdateParameters.Add("completiondate", null);
        }
    }
    protected void frmActivities_DataBound(object sender, EventArgs e)
    {
        Label Status = (Label)frmActivities.FindControl("lblStatus");
        //Change status colour if call is closed
        if (Status != null)
        {
            if (Status.Text == "Complete")
            { Status.CssClass = "label label-important"; }
            else { Status.CssClass = "label label-success"; }
        }
    }
}