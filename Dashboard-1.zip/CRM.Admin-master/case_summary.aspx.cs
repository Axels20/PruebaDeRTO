﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class case_summary : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void frmCaseSummary_DataBound(object sender, EventArgs e)
    {
        Label Status = (Label)frmCaseSummary.FindControl("lblStatus");
        //Change status colour if call is closed
        if (Status != null)
        {
            if (Status.Text == "Complete")
            { Status.CssClass = "label label-important"; }
            else { Status.CssClass = "label label-success"; }
        }
    }
    protected void frmCaseSummary_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        Response.Redirect("case_details.aspx?cid=" + Request.QueryString["cid"].ToString(), false);
    }
}