﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class activity_status : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack && Request.QueryString["aid"] != null)
        {
            DropDownList dropStatus = frmActivityStatus.FindControl("dropStatus") as DropDownList;
            HiddenField hdnStatus = frmActivityStatus.FindControl("hdnStatus") as HiddenField;
            dropStatus.SelectedValue = hdnStatus.Value;
        }
    }
    protected void frmActivityStatus_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    {
        DropDownList dropStatus = frmActivityStatus.FindControl("dropStatus") as DropDownList;
        HiddenField hdnStatus = frmActivityStatus.FindControl("hdnStatus") as HiddenField;
        if (dropStatus.SelectedValue != hdnStatus.Value) { dsActivityStatus.UpdateParameters.Add("status", dropStatus.SelectedValue.ToString()); }
        Response.Redirect("activity.aspx?aid=" + Request.QueryString["aid"].ToString(), false);
    }
}