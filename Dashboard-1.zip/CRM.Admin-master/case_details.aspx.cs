﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class case_details : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    public void frmCaseDetails_Bound(object sender, EventArgs e)
    {
        Label Status = (Label)frmCaseDetails.FindControl("lblStatus");
        //Change status colour if call is closed
        if (Status != null)
        {
            if (Status.Text == "Complete")
            { Status.CssClass = "label label-important"; }
            else { Status.CssClass = "label label-success"; }
        }
    }
    protected void frmCaseDetails_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    {
        TextBox Created = frmCaseDetails.FindControl("txtCreated") as TextBox;
        TextBox Target = frmCaseDetails.FindControl("txtTarget") as TextBox;
        TextBox Closed = frmCaseDetails.FindControl("txtClosed") as TextBox;
        TextBox Jeopardy = frmCaseDetails.FindControl("txtJeopardy") as TextBox;
        HiddenField CreatedTime = frmCaseDetails.FindControl("hdnCreateTime") as HiddenField;
        HiddenField TargetTime = frmCaseDetails.FindControl("hdnTargetTime") as HiddenField;
        HiddenField ClosedTime = frmCaseDetails.FindControl("hdnClosedTime") as HiddenField;
        HiddenField JeopardyTime = frmCaseDetails.FindControl("hdnJeopardyTime") as HiddenField;
        if (Created.Text != "")
        {
            dsCaseDetails.UpdateParameters.Add("createddate", System.Data.DbType.DateTime, Created.Text + " " + CreatedTime.Value);
        }
        else
        {
            dsCaseDetails.UpdateParameters.Add("createddate", null);
        }
        if (Target.Text != "")
        {
            dsCaseDetails.UpdateParameters.Add("target", System.Data.DbType.DateTime, Target.Text + " " + TargetTime.Value);
        }
        else
        {
            dsCaseDetails.UpdateParameters.Add("target", null);
        }
        if (Closed.Text != "")
        {
            dsCaseDetails.UpdateParameters.Add("completeddate", System.Data.DbType.DateTime, Closed.Text + " " + ClosedTime.Value);
        }
        else
        {
            dsCaseDetails.UpdateParameters.Add("completeddate", null);
        }
        if (Jeopardy.Text != "")
        {
            dsCaseDetails.UpdateParameters.Add("jeopardy", System.Data.DbType.DateTime, Jeopardy.Text + " " + JeopardyTime.Value);
        }
        else
        {
            dsCaseDetails.UpdateParameters.Add("jeopardy", null);
        }


    }
    protected void dsCaseActivities_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            //Show error message
            frmCaseDetails.Visible = false;
            lblError.Visible = true;
            lblError.Text = "The database is currently offline";

            //Set the exception handled property so it doesn't bubble-up
            e.ExceptionHandled = true;
        }
    }
}