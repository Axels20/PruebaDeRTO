﻿function isAnyKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode >= 0 && charCode <= 255)
        return false;
    return true;
}