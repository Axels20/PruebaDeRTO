﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class activity_comment_edit : System.Web.UI.Page
{
    protected void frmActivityComment_Updated(object sender, EventArgs e)
    { 
    Response.Redirect("activity.aspx?aid=" + Request.QueryString["aid"].ToString(), false);
    }
    protected void frmActivityComment_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    {
        TextBox DateCreated = frmActivityComment.FindControl("txtDateCreated") as TextBox;
        HiddenField TimeCreated = frmActivityComment.FindControl("hdnActivityCreatedTime") as HiddenField;
        dsActivityComment.UpdateParameters.Add("time_created", System.Data.DbType.DateTime, DateCreated.Text + " " + TimeCreated.Value);
    }
}