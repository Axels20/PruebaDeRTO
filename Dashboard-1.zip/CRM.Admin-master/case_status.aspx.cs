﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class case_status : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!Page.IsPostBack && Request.QueryString["cid"] != null)
        {
            DropDownList dropStatus = frmCaseStatus.FindControl("dropStatus") as DropDownList;
            HiddenField hdnStatus = frmCaseStatus.FindControl("hdnStatus") as HiddenField;
            dropStatus.SelectedValue = hdnStatus.Value;
        }
    }
    protected void frmCaseStatus_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    {
        DropDownList dropStatus = frmCaseStatus.FindControl("dropStatus") as DropDownList;
        HiddenField hdnStatus = frmCaseStatus.FindControl("hdnStatus") as HiddenField;
        if (dropStatus.SelectedValue != hdnStatus.Value) { dsCaseStatus.UpdateParameters.Add("status", dropStatus.SelectedValue.ToString()); }
        Response.Redirect("case_details.aspx?cid=" + Request.QueryString["cid"].ToString(), false);
    }
}