
using System;

namespace Bessie
{
	
	public class DoubleBufferedPanel: System.Windows.Forms.Panel
	{
		
		public DoubleBufferedPanel()
		{
			DoubleBuffered = true;
		}
	}
}
